# IFVG Lab redesign — report

September 24, 2026. The redesigned screens run inside both existing applications: the main application (`streamlit run scripts/dashboard.py`) and the dedicated application (`python scripts/run_ifsm_research_ui.py`). Every number is computed from the saved study records as CALCULATIONS.md defines it.

- No study was launched, resumed or re-run.
- No strategy, engine, account, cost, calendar or payout rule changed.
- No market data was downloaded, and nothing dated June 11, 2026 or later was read.
- Firms are never added together.

Every browser check ran on an isolated copy of the stores.

Screenshots of each screen beside its mock are in `screenshots/`. Every judgment call is in `DECISIONS_LOG.md`, where each earlier feature now lives is in `FEATURE_MAP.csv`, and every placeholder still showing is in `DATA_GAPS.md`.

## P0 — Map and gap list: Done and verified

- **Built:** a map of both application entry points, their stores, the funded readers, the market-data readers and every panel to reuse. `FEATURE_MAP.csv` places all 86 earlier features. The gap list is in `TASKS.md` and `DATA_GAPS.md`.
- **Left:** nothing.

## P1 — Foundation: Done and verified

- **Built:**
  - design tokens and components;
  - the dark left rail (My studies, Trade review, New study);
  - one shared firm selection per saved result;
  - money, percent, price and Chicago 12-hour formatting;
  - links that reopen the same screen;
  - a calculation module passing all 22 CALCULATIONS.md reference tests;
  - caching.
- **Left:** nothing.

## P2 — Funded results overview (mock 02): Done and verified

- **Built:** the status line with its details, the selection and unseen windows, the merged ranking, the firm switch, checks on the leader and the findings link.
- **Checked:** switching firm changes the table and the leader together, and the detail opens on the same firm. The leader matches the reference ($30,781.88; Sharpe 4.01; Sortino 18.82; worst drawdown $3,661).
- **Left:** the unseen window stays a placeholder until a confirmation run exists.

## P3 — Summary, Payouts and accounts, Settings and evidence (mocks 03, 04, 08): Done and verified

- **Built:**
  - tiles, the four-part verdict, findings with next steps, and key measures with a working 68/90/95% switch;
  - concentration and quality gates;
  - every earlier funded detail panel, re-homed;
  - the one-account chart with a plain explanation of how the account was lost;
  - the full settings, verification, corrections, limitations and decisions;
  - a download of the published review folder.
- **Left:** two gates and three gate inputs show "Not in export". The strategy replay didn't store them.

## P4 — Trades tab and Trade review (mocks 06, 09, 09b): Done and verified

- **Built:**
  - the result distribution, performance summary, both excursion charts, and the trade list with both fills of a half exit;
  - each trade row opens that exact trade in Trade review;
  - Trade review with four sources, real one-minute candles, setup zones from a verified saved record of the same execution, and numbered setup markers;
  - point in time, which hides everything later, including the result;
  - the full review form, saved per firm, account and trade in the existing ledger.
- **Left:**
  - Trades no verified configuration executed show "Setup zones weren't recorded for this study".
  - "+ New tag" is disabled, because the ledger has a fixed tag list.

## P5a — Risk and simulation, fixed floor (mocks 05, 05b): Done and verified

- **Built:** the payout race with editable loss limit and trigger, the resampled equity fan with the method switch, end values, losing streaks, and drawdown growth with its table.
- **Checked:** the fixed seed reproduces identically. "Run again" picks a new seed and says so. Values are within the stated tolerances.
- **Left:** nothing.

## P5b — Payout race with each firm's own rules: Done and verified

- **Built:** the same resampled orders run through the existing funded simulator, calling only its public ledger. It adds expected payouts before an account dies and expected cash per account bought.
- **Checked:** replaying the saved order reproduces all 128 saved results exactly. Runs on request: 1,000 paths in about 8 seconds.
- **Left:** TakeProfitTrader is labeled approximate, because the saved trades don't record when their high came.

## P6 — Market conditions (mock 07): Done and verified

- **Built:** condition labels, the four cards, the profit chart shaded by condition, the transition table, and the entry-condition scatter with its measure switch and link badge.
- **Checked:** day counts and per-condition totals match the reference. The entry-day/exit-day switch works; here both give the same counts, and the screen says why.
- **Left:** nothing.

## P7 — My studies, New funded comparison, Review and approve (mocks 01, 10, 10b, 11, 11b): Done and verified

- **Built:**
  - My studies across both applications' stores, with the five tabs and only "Open results" and "Continue draft";
  - the setup page with the S0_D80_W1_P1 default and the legacy warning, the date range with the resolved trading-day count, readable chips, and the two new settings;
  - the review page with varying settings first, validated pass/fail checks and the blocked-engine lock.
- **Checked:** nothing launches. Approval goes through the existing gated path. Saved drafts reopen unchanged.
- **Left:** the withdrawal trigger, gap rule, other dates and changed checks are saved but block approval until the simulator or engine supports them. The mock's 48-configuration plan builds 36 configurations, because the half exit exists only at 1R.

## P8 — Consistency sweep and handoff: Done and verified

- **Built:**
  - Chicago 12-hour times, plain-English labels and one placeholder style on every redesigned screen;
  - the earlier wizards and result pages inside the shared rail and tokens, with full-length selection chips;
  - the earlier funded results screen replaced everywhere by the new overview;
  - this handoff folder.
- **Left:** nothing.

## Load time (seconds, isolated application; first open on a freshly started server, then cached)

| Screen | First open | Cached |
|---|---|---|
| My studies | 3.7 | 0.2 |
| Funded results | 3.1 | 0.4 |
| Summary | 3.2 | 0.3 |
| Payouts and accounts | 2.9 | 0.4 |
| Risk and simulation | 3.7 | 0.7 |
| Trades | 2.9 | 0.5 |
| Market conditions | 3.4 | 0.4 |
| Settings and evidence | 2.8 | 0.4 |
| Trade review | 3.8 | 0.5 |
| New funded comparison | 1.8 | 0.3 |
| Review and approve | 2.1 | 0.4 |

The first open includes verifying and loading the 55 MB saved result.

## Verification

- **Calculations:**
  - Every CALCULATIONS.md reference value is tested: 22 tests pass.
  - The redesign test folder has 222 passed and 1 skipped, which is a test that needs the half-exit engine.
- **Full test suite, on the final code:** 3,761 passed, 3 skipped.
  - Five failures are the pre-existing ones listed by the repair task: the frozen CatBoost bundle, the HTF cap experiment, and three capture-scheme tag tests.
  - Two older screen tests also failed, because they still expected the old "New study" chooser. They now click "Other study types" first, keep the same assertions, and pass.
  - Lint (`ruff check src tests scripts`) is clean.
- **Independent review:** four read-only reviewers looked at money and boundaries, calculations, navigation, and robustness. They found no blocker.
  - Every finding was fixed, each with a test that fails without the fix.
  - The largest fix: the earlier configurator now refuses approval and launch while a draft's new settings are blocked on Review and approve.
- **In the running application:**
  - every mock screen was captured beside its mock, and every control the mocks show working was clicked;
  - nothing was launched, and approval was never clicked;
  - all of this used an isolated copy of the stores.
- **Saved records:** all 22,619 snapshotted study, draft, approval, review and export files are identical before and after the task.

## For the owner

- In point in time, the default moment for the April 12 trade is 7:10 PM. Its half exit filled at 7:10:27 PM, so the half exit is hidden at that moment; the mock showed it. It appears from the 7:15 PM moment on.
- Open decision, unchanged: the time-under-water limit (saved at 3 days; you're weighing 18–20).
