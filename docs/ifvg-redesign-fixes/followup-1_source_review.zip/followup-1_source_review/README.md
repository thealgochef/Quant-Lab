# Source-review attachment: setup-timing follow-up

This attachment holds before and after copies of every source and test file the follow-up
changed. Both sides are taken from git trees, not from a working copy.

- `before/` is the delivered closeout's source, tree `76bb3b0c514b0d1fba2fcfec17beb1694943b6c7`.
- `after/` is the corrected source, tree `41d2288af68bea7810c584579af3786028f3914d`. The mutation probes ran on that tree. The
  focused checks ran on tree `814dfe4e…`, which differs from it only in one document
  (`followup-1/DEMONSTRATION.md`); its src, scripts, tests and pyproject.toml are identical.
- `changes.diff` is the diff between them for these files.
- `SOURCE_IDENTITY.json` gives the blob ids of each file before and after.
- `after/` also contains the unchanged modules that `review_panels.py` imports, so the helper
  imports from this attachment alone. They are the package `__init__` files,
  `chicago_time.py`, `format.py`, `html.py`, `minute_companion.py` and `setup_records.py`.

**What runs on its own.** Put `after/src` on PYTHONPATH (pandas is needed) and
`review_panels.setup_steps`, `setup_key` and `moments` run on a hand-built record. For the
delivered version, put `before/`'s `review_panels.py` in its place. The assembler of this
follow-up did exactly that from the extracted ZIP and replayed the owner's boundary with each
version; the result is in `validation_summary.json` (`source_review_attachment`).

**What does not run on its own.** The screens need Streamlit and the rest of the application,
and the tests need the repository's fixtures. They ran in the repository, in the checks listed
in `validation_summary.json`. No repository, environment, store or market data is included.
