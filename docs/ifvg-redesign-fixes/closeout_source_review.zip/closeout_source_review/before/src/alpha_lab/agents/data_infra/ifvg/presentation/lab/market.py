"""Index measures from the study's stored one-minute E-mini bars (read only).

The bars come from the funded plan's bound, verified strategy package
(``shared/market_bars.parquet``; the package is opened through
:func:`plan_strategy_package`, which checks its run id and manifest hash).
Nothing is downloaded and no day after the study's cutoff is read.

``CALCULATIONS.md``: daily close = the last one-minute close of each trading
day; beta = least-squares slope of daily results on the daily E-mini change ×
$20; buy and hold one E-mini = (last trading day's close − first trading day's
close) × $20, with the first time its fall from a running high reached $2,000
on one-minute closes; market-condition labels from the previous 10 trading days.
"""

from __future__ import annotations

from collections import Counter
from collections.abc import Sequence
from dataclasses import dataclass, field
from datetime import time as dt_time
from datetime import timedelta
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

__all__ = [
    "CONDITIONS",
    "ENTRY_MEASURES",
    "E_MINI_POINT_VALUE",
    "NOT_ENOUGH",
    "BuyAndHold",
    "ConditionCard",
    "ConditionLabels",
    "EntryMeasure",
    "IndexTie",
    "Stretch",
    "buy_and_hold",
    "condition_cards",
    "condition_labels",
    "daily_closes",
    "entry_measure",
    "index_tie",
    "load_index_minutes",
    "longest_stretch",
    "stretches",
    "study_package_root",
    "trade_day",
    "transition_table",
]

E_MINI_POINT_VALUE = 20.0
TICK = 0.25
NOT_ENOUGH = "Not enough history"
CONDITIONS = ("Rising · quiet", "Rising · volatile", "Falling · quiet", "Falling · volatile")
LOOKBACK = 10


def study_package_root(plan: Any) -> Path | None:
    """The plan's bound verified strategy package (run id and manifest hash must match)."""

    if plan is None or getattr(plan, "source", None) is None:
        return None
    from alpha_lab.agents.data_infra.ifvg.presentation.funded_trade_review import (
        plan_strategy_package,
    )
    from alpha_lab.propsim.funded.sources import ARCHIVE_ROOT

    return plan_strategy_package(plan, ARCHIVE_ROOT)


def load_index_minutes(package_root: Path, *, cutoff_utc: Any = None) -> pd.DataFrame:
    """One-minute E-mini bars of the package (prices in index points), in time order."""

    bars = pd.read_parquet(
        Path(package_root) / "shared/market_bars.parquet",
        columns=["timeframe_seconds", "trading_day", "logical_open_ts_utc",
                 "logical_close_ts_utc", "open_ticks", "high_ticks", "low_ticks",
                 "close_ticks", "volume"])
    bars = bars[bars["timeframe_seconds"] == 60].copy()
    if cutoff_utc is not None:
        bars = bars[bars["logical_close_ts_utc"] <= pd.Timestamp(cutoff_utc)]
    for column in ("open", "high", "low", "close"):
        bars[column] = bars[f"{column}_ticks"].astype(float) * TICK
    bars["trading_day"] = bars["trading_day"].astype(str)
    return bars.sort_values("logical_close_ts_utc").reset_index(drop=True)


def daily_closes(minutes: pd.DataFrame) -> pd.Series:
    """Last one-minute close of each stored trading day (points), by trading day."""

    return minutes.groupby("trading_day", sort=True)["close"].last()


# ── tie to the index ──────────────────────────────────────────────────────


@dataclass(frozen=True)
class IndexTie:
    beta: float | None
    r_squared: float | None
    days: int


def index_tie(daily: Sequence[tuple[str, float]], closes: pd.Series) -> IndexTie:
    """Slope of daily results on the daily E-mini change × $20 over the same days."""

    days = list(closes.index)
    change: dict[str, float] = {}
    for previous, day in zip(days, days[1:], strict=False):
        change[day] = (float(closes[day]) - float(closes[previous])) * E_MINI_POINT_VALUE
    pairs = [(change[d], v) for d, v in daily if d in change]
    if len(pairs) < 3:
        return IndexTie(None, None, len(pairs))
    x = np.asarray([p[0] for p in pairs])
    y = np.asarray([p[1] for p in pairs])
    if x.var() == 0:
        return IndexTie(None, None, len(pairs))
    slope, intercept = np.polyfit(x, y, 1)
    fitted = slope * x + intercept
    total = float(((y - y.mean()) ** 2).sum())
    r2 = 1.0 - float(((y - fitted) ** 2).sum()) / total if total else None
    return IndexTie(float(slope), r2, len(pairs))


@dataclass(frozen=True)
class BuyAndHold:
    result: float | None
    first_close: float | None
    last_close: float | None
    breach_utc: pd.Timestamp | None
    limit: float


def buy_and_hold(minutes: pd.DataFrame, calendar: Sequence[str], *,
                 limit: float = 2000.0) -> BuyAndHold:
    """Hold one E-mini over the study's trading days.

    The result is (last trading day's close − first trading day's close) × $20.
    The fall from a running high is followed on one-minute closes from the
    first bar of the first trading day (the 5:00 PM open), the stricter reading.
    """

    if not calendar:
        return BuyAndHold(None, None, None, None, limit)
    closes = daily_closes(minutes)
    first, last = calendar[0], calendar[-1]
    if first not in closes.index or last not in closes.index:
        return BuyAndHold(None, None, None, None, limit)
    window = minutes[minutes["trading_day"].isin(set(calendar))]
    path = window["close"].to_numpy(dtype=float)
    fall = (np.maximum.accumulate(path) - path) * E_MINI_POINT_VALUE
    hit = np.flatnonzero(fall >= limit)
    breach = window["logical_close_ts_utc"].iloc[int(hit[0])] if hit.size else None
    return BuyAndHold(
        result=(float(closes[last]) - float(closes[first])) * E_MINI_POINT_VALUE,
        first_close=float(closes[first]), last_close=float(closes[last]),
        breach_utc=breach, limit=limit)


# ── market conditions ─────────────────────────────────────────────────────


@dataclass(frozen=True)
class ConditionLabels:
    #: study trading day → label (one of CONDITIONS or NOT_ENOUGH)
    labels: dict[str, str]
    first_labeled: str | None
    volatility_median: float | None


def condition_labels(closes: pd.Series, calendar: Sequence[str]) -> ConditionLabels:
    """Rising/Falling against the close 10 trading days earlier; Volatile/Quiet vs the median.

    Volatility = sample standard deviation of the last 10 daily percentage
    changes; Volatile when above the median of that measure over the study's
    labeled trading days. "10 trading days earlier" counts stored trading days.
    """

    days = list(closes.index)
    position = {d: i for i, d in enumerate(days)}
    pct = closes.pct_change()
    trend: dict[str, str] = {}
    vol: dict[str, float] = {}
    for day in calendar:
        i = position.get(day)
        if i is None or i < LOOKBACK:
            continue
        trend[day] = "Rising" if closes.iloc[i] > closes.iloc[i - LOOKBACK] else "Falling"
        vol[day] = float(pct.iloc[i - LOOKBACK + 1: i + 1].std(ddof=1))
    median = float(np.median(list(vol.values()))) if vol else None
    labels = {}
    for day in calendar:
        if day in trend and median is not None:
            labels[day] = f"{trend[day]} · {'Volatile' if vol[day] > median else 'Quiet'}".replace(
                "· Volatile", "· volatile").replace("· Quiet", "· quiet")
        else:
            labels[day] = NOT_ENOUGH
    first = next((d for d in calendar if labels[d] != NOT_ENOUGH), None)
    return ConditionLabels(labels=labels, first_labeled=first, volatility_median=median)


@dataclass(frozen=True)
class ConditionCard:
    label: str
    days: int
    trades: int
    share_of_trades: float | None
    net: float
    win_rate: float | None
    average: float | None
    first_day: str | None = None
    last_day: str | None = None


def trade_day(trade: dict[str, Any], by: str) -> str:
    """The trading day a trade is labeled by: its entry's, or its exit's.

    A trading day runs from the 5:00 PM open to the 4:00 PM close and is named
    by its closing date; the saved ``trading_day`` is the entry's trading day.
    """

    if by == "entry":
        return str(trade.get("trading_day"))
    from alpha_lab.agents.data_infra.ifvg.presentation.chicago_time import CHICAGO, utc_instant

    stamp = utc_instant(trade.get("exit_utc"))
    if stamp is None:
        return str(trade.get("trading_day"))
    local = stamp.tz_convert(CHICAGO)
    # 5:00 PM onward belongs to the next calendar day's trading day
    day = (local + pd.Timedelta(days=1)).date() if local.hour >= 17 else local.date()
    return day.isoformat()


def condition_cards(labels: ConditionLabels, trades: Sequence[dict[str, Any]], *,
                    by: str = "entry") -> list[ConditionCard]:
    counts = Counter(labels.labels.values())
    total = len(trades)
    grouped: dict[str, list[float]] = {name: [] for name in (*CONDITIONS, NOT_ENOUGH)}
    for trade in trades:
        label = labels.labels.get(trade_day(trade, by), NOT_ENOUGH)
        grouped.setdefault(label, []).append(float(trade.get("net_pnl_usd") or 0.0))
    cards = []
    for name in (*CONDITIONS, NOT_ENOUGH):
        values = np.asarray(grouped.get(name, []), dtype=float)
        days = [d for d, lab in labels.labels.items() if lab == name]
        cards.append(ConditionCard(
            label=name, days=counts.get(name, 0), trades=int(values.size),
            share_of_trades=(values.size / total) if total else None,
            net=float(values.sum()),
            win_rate=float((values > 0).mean()) if values.size else None,
            average=float(values.mean()) if values.size else None,
            first_day=days[0] if days else None, last_day=days[-1] if days else None))
    return cards


def transition_table(labels: ConditionLabels) -> dict[str, dict[str, int]]:
    """Counts of consecutive labeled study days: from today's label to tomorrow's."""

    sequence = [lab for lab in labels.labels.values()]
    table = {a: dict.fromkeys(CONDITIONS, 0) for a in CONDITIONS}
    for today, tomorrow in zip(sequence, sequence[1:], strict=False):
        if today in table and tomorrow in table[today]:
            table[today][tomorrow] += 1
    return table


@dataclass(frozen=True)
class Stretch:
    label: str
    first_day: str
    last_day: str
    days: int
    net: float = 0.0
    trading_days: tuple[str, ...] = field(default=(), repr=False)


def stretches(labels: ConditionLabels, daily: Sequence[tuple[str, float]]) -> list[Stretch]:
    """Runs of consecutive study days with the same label, with their net result."""

    result = dict(daily)
    out: list[Stretch] = []
    run: list[str] = []
    current = None
    for day, label in labels.labels.items():
        if label != current and run:
            out.append(Stretch(current, run[0], run[-1], len(run),
                               round(sum(result.get(d, 0.0) for d in run), 2), tuple(run)))
            run = []
        current = label
        run.append(day)
    if run:
        out.append(Stretch(current, run[0], run[-1], len(run),
                           round(sum(result.get(d, 0.0) for d in run), 2), tuple(run)))
    return out


def longest_stretch(items: Sequence[Stretch]) -> Stretch | None:
    labeled = [s for s in items if s.label != NOT_ENOUGH]
    return max(labeled, key=lambda s: (s.days, s.first_day)) if labeled else None


# ── entry conditions ──────────────────────────────────────────────────────

ENTRY_MEASURES = {
    "volatility": ("Volatility", "Average one-minute range over the last 20 minutes",
                   "Average true range of the 20 one-minute bars that closed by the entry, "
                   "divided by the entry price."),
    "trend": ("Trend", "Price change over the last hour",
              "Change of the one-minute close over the 60 bars before the entry, divided by "
              "the close 60 bars earlier."),
    "volume": ("Volume", "Contracts traded in the last 20 minutes",
               "E-mini contracts traded in the 20 one-minute bars that closed by the entry."),
    "time": ("Time of day", "Hours since the 5:00 PM open",
             "Hours from the trading day's 5:00 PM Chicago open to the entry."),
}


@dataclass(frozen=True)
class EntryMeasure:
    measure: str
    x: tuple[float, ...]
    r_multiple: tuple[float, ...]
    winner: tuple[bool, ...]
    correlation: float | None
    p_value: float | None
    clear_link: bool


def _entry_x(minutes: pd.DataFrame, closes_ns: np.ndarray, trade: dict[str, Any],
             measure: str) -> float | None:
    from alpha_lab.agents.data_infra.ifvg.presentation.chicago_time import CHICAGO, utc_instant

    entry = utc_instant(trade.get("entry_utc"))
    if entry is None:
        return None
    end = int(np.searchsorted(closes_ns, entry.value, side="right"))
    if measure == "time":
        local = entry.tz_convert(CHICAGO)
        # the 5:00 PM open on the wall clock (not 17 elapsed hours: DST Sundays)
        start = pd.Timestamp.combine(local.date(), dt_time(17)).tz_localize(CHICAGO)
        if local < start:
            start = pd.Timestamp.combine(local.date() - timedelta(days=1),
                                         dt_time(17)).tz_localize(CHICAGO)
        return (local - start).total_seconds() / 3600.0
    if measure == "trend":
        if end < 61:
            return None
        now, before = minutes["close"].iat[end - 1], minutes["close"].iat[end - 61]
        return float((now - before) / before)
    if end < 21:
        return None
    window = minutes.iloc[end - 20: end]
    if measure == "volume":
        return float(window["volume"].sum())
    previous = minutes["close"].iloc[end - 21: end - 1].to_numpy()
    high, low = window["high"].to_numpy(), window["low"].to_numpy()
    true_range = np.maximum(high, previous) - np.minimum(low, previous)
    price = float(trade.get("entry_ticks") or 0) * TICK or float(window["close"].iat[-1])
    return float(true_range.mean() / price)


def entry_measure(minutes: pd.DataFrame, trades: Sequence[dict[str, Any]], *,
                  measure: str = "volatility") -> EntryMeasure:
    """One entry-condition measure per trade against its result in multiples of initial risk."""

    closes_ns = minutes["logical_close_ts_utc"].astype("int64").to_numpy()
    xs, rs, wins = [], [], []
    for trade in trades:
        risk = float(trade.get("initial_risk_usd") or 0.0)
        value = _entry_x(minutes, closes_ns, trade, measure)
        if value is None or risk <= 0:
            continue
        result = float(trade.get("net_pnl_usd") or 0.0)
        xs.append(value)
        rs.append(result / risk)
        wins.append(result > 0)
    correlation = p_value = None
    if len(xs) >= 3 and np.std(xs) > 0 and np.std(rs) > 0:
        from scipy.stats import pearsonr

        test = pearsonr(xs, rs)
        correlation, p_value = float(test.statistic), float(test.pvalue)
    clear = (correlation is not None and abs(correlation) >= 0.1
             and p_value is not None and p_value < 0.05)
    return EntryMeasure(measure=measure, x=tuple(xs), r_multiple=tuple(rs), winner=tuple(wins),
                        correlation=correlation, p_value=p_value, clear_link=clear)


#: the earlier private name, kept for callers written before it was public
_trade_day = trade_day
