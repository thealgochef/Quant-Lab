"""Payout race — full version: resampled trade orders through the funded account simulator.

``CALCULATIONS.md`` "Payout race — full version" and TASK.md section 4.2. The
fixed-floor race (:func:`.resampling.payout_race`) treats every account as a
flat −$2,000 limit and a +$2,600 trigger. This version feeds the SAME resampled
trade orders through the existing one-account ledger of the funded simulator
(:class:`alpha_lab.propsim.funded.pair_ledger.PairLedger`), so the selected
firm's own trailing floor, floor lock, payout protection ("finished for
today"), end-of-day request, processing clock and replacement purchases apply.
Only the ledger's public interface is called; no firm rule is copied here and
no simulator code is changed. Firm terms, the processing clock and the sizing
come from the saved result's frozen settings; the trading calendar from the
study's verified strategy package.

How a saved trade becomes a synthetic trade (the adapter)
---------------------------------------------------------

The study's funded trades are the "slots": each keeps its own entry instant,
exit instant and trading day, in the original order. A resampled order puts
the recorded OUTCOME of one saved trade into each slot, as a short ordered price
path inside the trade's own time window:

* entry at the recorded entry price, exit at the recorded exit price (the path
  closes there at the slot's exit instant, the way the simulator closes a
  position at its daily deadline);
* the recorded lowest equity during the trade becomes a price point (the
  "worst point") and the recorded highest equity another (the "best point"),
  converted back to whole ticks with the trade's own quantity, tick value and
  costs;
* a half-exit trade touches its recorded 1R target, where the simulator's own
  scale-out exits half the contracts and moves the stop of the rest to the
  entry price;
* the order's stop sits one tick beyond the worst point and its target one tick
  beyond the best point, so neither triggers by itself: the recorded exit price
  is kept. The loss limit is still checked by the simulator on every point.

Which came first, the worst or the best point, is saved only partly (the time of
the lowest equity is saved, the time of the highest is not). Where the record
pins the order it is used; where it does not, the best point is placed first,
the stricter choice for a floor that trails the highest equity (rule 8). A
MyFundedFutures floor only moves at the session close, so its results do not
depend on that order; TakeProfitTrader's trailing floor does, and its results
are labelled approximate. A trade that ended because an account was lost keeps
its recorded (truncated) result, like every other resampled figure.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from alpha_lab.agents.data_infra.ifvg.presentation.chicago_time import utc_instant
from alpha_lab.agents.data_infra.ifvg.presentation.lab.funded_data import (
    FundedStudy,
    ordered_trades,
    pair_key,
)
from alpha_lab.agents.data_infra.ifvg.presentation.lab.resampling import resample_paths

__all__ = [
    "DEFAULT_FULL_PATHS",
    "FULL_PATH_CHOICES",
    "FirmRules",
    "FullRace",
    "LedgerOutcome",
    "Slot",
    "TradeShape",
    "Validation",
    "build_inputs",
    "check_original",
    "extension_seed",
    "MinuteIndex",
    "open_source",
    "firm_rules",
    "firm_terms",
    "full_race",
    "ledger_outcome",
    "race_orders",
    "replay",
    "shared_trades",
    "slots_from_rows",
    "trade_shape",
    "validate_original_order",
]

MINUTE_NS = 60_000_000_000
#: the full version is slower than the fixed-floor race: fewer paths by default
DEFAULT_FULL_PATHS = 1_000
FULL_PATH_CHOICES = (500, 1_000, 2_000)
#: every resampled order is drawn this long, as in the fixed-floor race, so the
#: full version uses exactly the same orders (their first ``min(slots, 200)``
#: trades; a longer study continues each path from a derived seed)
RACE_DRAW_LENGTH = 200


# ── the saved inputs ──────────────────────────────────────────────────────


def _cents(usd: Any) -> int:
    return int(round(float(usd) * 100))


def _ns(value: Any) -> int:
    stamp = utc_instant(value)
    if stamp is None:
        raise ValueError(f"missing time {value!r}")
    return int(stamp.value)


def firm_terms(study: FundedStudy, firm_key: str) -> dict[str, Any] | None:
    """The firm's frozen terms as saved in the result (``settings.firm_profiles``)."""

    for profile in (study.result.get("settings") or {}).get("firm_profiles") or []:
        if profile.get("firm_key") == firm_key:
            return dict(profile)
    return None


@dataclass(frozen=True)
class Slot:
    """One saved trade's place in time: entry, exit and trading day."""

    entry_ns: int
    exit_ns: int
    trading_day: str


@dataclass(frozen=True)
class TradeShape:
    """One saved trade's recorded outcome as a synthetic ordered price path."""

    index: int
    direction: str
    entry_ticks: int
    exit_ticks: int
    stop_ticks: int  # the order's stop: one tick beyond every point before the exit
    target_ticks: int  # the recorded target for a half exit; else beyond the best point
    path_ticks: tuple[int, ...]  # observations after the entry, ending at the exit
    net_cents: int  # recorded net result (for checks)
    scaled: bool
    order_pinned: bool  # the record fixes whether the worst or best point came first
    exact: bool  # worst and best points converted to whole ticks without rounding


@dataclass(frozen=True)
class FirmRules:
    """Everything the funded ledger needs for one configuration at one firm."""

    pair_id: str
    configuration: str
    firm_key: str
    firm_name: str
    profile: Any  # FundedFirmProfile
    processing: Any  # ProcessingClockPolicy
    quantity: int
    tick_value_cents: int
    cost_per_contract_mills: int
    scale_out: bool
    trading_days: tuple[Any, ...]  # TradingDay
    start_ns: int
    cutoff_ns: int

    @property
    def loss_allowance(self) -> float:
        return self.profile.loss_allowance_cents / 100

    @property
    def trigger(self) -> float:
        return (self.profile.retained_cushion_cents
                + self.profile.minimum_gross_request_cents) / 100


def _sizing(study: FundedStudy, configuration: str) -> tuple[int, int, int, bool]:
    settings = study.result.get("settings") or {}
    by_configuration = settings.get("sizing_by_configuration") or {}
    sizing = by_configuration.get(configuration)
    if sizing is not None:
        mills = int(round(float(sizing["cost_per_contract_per_fill_usd"]) * 1000))
        scale_out = str(sizing.get("exit_policy") or "fixed_target_v1") != "fixed_target_v1"
        return int(sizing["quantity"]), int(sizing["tick_value_cents"]), mills, scale_out
    if "quantity" in settings and "tick_value_cents" in settings:  # single-size plans
        return (int(settings["quantity"]), int(settings["tick_value_cents"]),
                int(round(float(settings["cost_per_side_usd"]) * 1000)), False)
    raise ValueError("the saved result does not record this configuration's size")


def firm_rules(study: FundedStudy, configuration: str, firm_key: str, *,
               source: Any) -> FirmRules:
    """Build the ledger inputs from the saved result and the verified package source.

    ``source`` is the study's :class:`ComparisonSource` (``open_comparison_source``
    on the plan's verified strategy package): its trading days, start and cutoff.
    """

    from alpha_lab.propsim.funded.clock import ProcessingClockPolicy
    from alpha_lab.propsim.funded.profiles import FundedFirmProfile

    terms = firm_terms(study, firm_key)
    if terms is None:
        raise ValueError(f"the saved result has no terms for {firm_key}")
    settings = study.result.get("settings") or {}
    clock = settings.get("processing_clock")
    if not clock:
        raise ValueError("the saved result has no payout-processing clock")
    quantity, tick_value, mills, scale_out = _sizing(study, configuration)
    profile = FundedFirmProfile.model_validate(terms)
    return FirmRules(
        pair_id=pair_key(configuration, firm_key), configuration=configuration,
        firm_key=firm_key, firm_name=profile.firm_name, profile=profile,
        processing=ProcessingClockPolicy.model_validate(clock), quantity=quantity,
        tick_value_cents=tick_value, cost_per_contract_mills=mills, scale_out=scale_out,
        trading_days=tuple(source.trading_days), start_ns=int(source.start_ns),
        cutoff_ns=int(source.cutoff_ns))


def slots_from_rows(rows: Sequence[dict[str, Any]]) -> tuple[Slot, ...]:
    return tuple(Slot(entry_ns=_ns(r["entry_utc"]), exit_ns=_ns(r["exit_utc"]),
                      trading_day=str(r["trading_day"])) for r in rows)


def _fill_cost(quantity: int, mills: int) -> int:
    from alpha_lab.propsim.funded.position_walk import fill_cost_cents

    return fill_cost_cents(quantity, mills) if quantity else 0


def _to_ticks(equity: int, base: int, per_tick: int, sign: int, *, worse: bool
              ) -> tuple[int, bool]:
    """Price (ticks from the entry) where ``base + move × per_tick`` equals ``equity``."""

    move, remainder = divmod(equity - base, per_tick)
    exact = remainder == 0
    if not exact and not worse:
        move += 1  # round a best point away from the entry only when inexact
    return sign * move, exact


@dataclass(frozen=True)
class MinuteIndex:
    """The study's stored one-minute E-mini bars, for ordering a trade's best and worst."""

    open_ns: np.ndarray
    high_ticks: np.ndarray
    low_ticks: np.ndarray

    @classmethod
    def from_frame(cls, frame: Any) -> MinuteIndex:
        stamps = frame["logical_open_ts_utc"].dt.tz_convert("UTC").dt.tz_localize(None)
        return cls(open_ns=np.asarray(stamps, dtype="datetime64[ns]").astype(np.int64),
                   high_ticks=np.asarray(frame["high_ticks"], dtype=np.int64),
                   low_ticks=np.asarray(frame["low_ticks"], dtype=np.int64))

    def first_reach(self, start_ns: int, end_ns: int, price: int, sign: int) -> int | None:
        """Open instant of the first minute after ``start_ns`` that reached ``price``."""

        lo = int(np.searchsorted(self.open_ns, start_ns, side="left"))
        hi = int(np.searchsorted(self.open_ns, end_ns, side="right"))
        if hi <= lo:
            return None
        window = self.high_ticks[lo:hi] >= price if sign > 0 else self.low_ticks[lo:hi] <= price
        if not bool(window.any()):
            return None
        return int(self.open_ns[lo + int(np.argmax(window))])


def _best_first(minutes: MinuteIndex | None, entry_ns: int, exit_ns: int, best: int,
                sign: int, low_ns: int | None) -> bool | None:
    """True/False when the stored minutes show whether the best point came first."""

    if minutes is None or low_ns is None:
        return None
    reached = minutes.first_reach(entry_ns, exit_ns, best, sign)
    if reached is None:
        return None
    low_minute = low_ns - low_ns % MINUTE_NS
    if reached < low_minute:
        return True
    if reached > low_minute:
        return False
    return None  # the same minute: the order inside it is not stored


def trade_shape(row: dict[str, Any], index: int, *, tick_value_cents: int, mills: int,
                minutes: MinuteIndex | None = None) -> TradeShape:
    """Turn one saved funded trade into a synthetic ordered path (see the module notes)."""

    sign = 1 if str(row["direction"]) == "long" else -1
    entry = int(row["entry_ticks"])
    exit_ = int(row["exit_ticks"])
    quantity = int(row["quantity"])
    half = int(row.get("scale_out_quantity") or 0)
    scaled = row.get("scale_out_ns") is not None and half > 0
    balance = _cents(row["balance_before_usd"])
    after_entry = balance - _fill_cost(quantity, mills)
    low, high = _cents(row["min_equity_usd"]), _cents(row["max_equity_usd"])
    entry_ns, exit_ns = _ns(row["entry_utc"]), _ns(row["exit_utc"])
    low_ns = _ns(row["min_equity_utc"]) if row.get("min_equity_utc") else None
    full = tick_value_cents * quantity
    exact = True

    if not scaled:
        worst_move, ok_w = _to_ticks(low, after_entry, full, 1, worse=True)
        best_move, ok_b = _to_ticks(high, after_entry, full, 1, worse=False)
        exact = ok_w and ok_b
        worst, best = entry + sign * worst_move, entry + sign * best_move
        low_at_exit = low_ns is not None and low_ns >= exit_ns
        target_exit = str(row.get("exit_kind")) == "target"
        hint = (None if low_at_exit or target_exit
                else _best_first(minutes, entry_ns, exit_ns, best, sign, low_ns))
        if low_at_exit:  # the lowest point was the exit itself: the best came first
            points, pinned = [best, exit_], True
        elif target_exit:  # the target fill is the highest point: the worst came first
            points, pinned = [worst, exit_], True
        elif hint is False:  # the stored minutes show the worst point came first
            points, pinned = [worst, best, exit_], True
        else:  # best first: shown by the minutes, or not pinned (stricter for a
            # floor that trails the highest equity)
            points, pinned = [best, worst, exit_], hint is True
        before_exit = [entry, *points[:-1]]
        stop = min(p * sign for p in before_exit) * sign - sign
        target = max(p * sign for p in [*before_exit, exit_]) * sign + sign
        return TradeShape(index=index, direction=str(row["direction"]), entry_ticks=entry,
                          exit_ticks=exit_, stop_ticks=stop, target_ticks=target,
                          path_ticks=tuple(int(p) for p in points),
                          net_cents=_cents(row["net_pnl_usd"]), scaled=False,
                          order_pinned=pinned, exact=exact)

    target = int(row["target_ticks"])
    scale_ns = int(row["scale_out_ns"])
    rest = quantity - half
    after_half = (after_entry + (target - entry) * sign * tick_value_cents * half
                  - _fill_cost(half, mills))
    at_target_before_half = after_entry + (target - entry) * sign * full
    points: list[int] = []
    low_before_half = low_ns is not None and low_ns < scale_ns
    if low_before_half:
        worst_move, ok_w = _to_ticks(low, after_entry, full, 1, worse=True)
        exact = exact and ok_w
        points.append(entry + sign * worst_move)
    points.append(target)
    after: list[int] = []
    best = None
    if high > at_target_before_half:
        best_move, ok_b = _to_ticks(high, after_half, tick_value_cents * rest, 1, worse=False)
        exact = exact and ok_b
        best = entry + sign * best_move
        if best * sign > target * sign:
            after.append(best)
        else:
            best = None
    pinned = True
    if not low_before_half and low_ns is not None and low_ns < exit_ns:
        # the lowest point came after the half exit and before the final exit
        low_move, ok_l = _to_ticks(low, after_half, tick_value_cents * rest, 1, worse=True)
        exact = exact and ok_l
        low_price = entry + sign * low_move
        if low_price * sign > entry * sign:  # never below the break-even stop
            hint = (None if best is None
                    else _best_first(minutes, scale_ns, exit_ns, best, sign, low_ns))
            if hint is False:
                after.insert(0, low_price)
            else:
                after.append(low_price)
                pinned = best is None or hint is True
    points.extend(after)
    points.append(exit_)
    before_target = [entry, *points[:points.index(target)]]
    stop = min(p * sign for p in before_target) * sign - sign
    return TradeShape(index=index, direction=str(row["direction"]), entry_ticks=entry,
                      exit_ticks=exit_, stop_ticks=stop, target_ticks=target,
                      path_ticks=tuple(int(p) for p in points),
                      net_cents=_cents(row["net_pnl_usd"]), scaled=True,
                      order_pinned=pinned, exact=exact)


# ── one replay through the funded ledger ──────────────────────────────────


def _ledger(rules: FirmRules):
    from alpha_lab.propsim.funded.pair_ledger import PairLedger

    return PairLedger(
        pair_id=rules.pair_id, configuration=rules.configuration, profile=rules.profile,
        processing=rules.processing, quantity=rules.quantity,
        tick_value_cents=rules.tick_value_cents, cost_per_side_cents=0,
        trading_days=rules.trading_days, start_ns=rules.start_ns, cutoff_ns=rules.cutoff_ns,
        cost_per_contract_mills=rules.cost_per_contract_mills, scale_out=rules.scale_out)


def _observations(slot: Slot, shape: TradeShape):
    from alpha_lab.propsim.funded.position_walk import MinuteObservations

    # the entry price, then the recorded points: legs between them are treated as
    # continuous (a loss limit crossed on the way is met at its own level), and the
    # last step to the recorded exit is a jump so the exit fills at its recorded price
    points = (shape.entry_ticks, *shape.path_ticks)
    close_ns = max(slot.exit_ns, slot.entry_ns + len(points) + 1)
    step = max(1, (close_ns - slot.entry_ns) // (len(points) + 1))
    stamps = [slot.entry_ns + step * k for k in range(len(points))]
    continuous = np.ones(len(points), dtype=bool)
    continuous[0] = continuous[-1] = False
    return MinuteObservations(
        open_ns=slot.entry_ns, close_ns=close_ns, close_ticks=shape.exit_ticks,
        ts_ns=np.array(stamps, dtype=np.int64),
        price_ticks=np.array(points, dtype=np.int64), continuous=continuous,
        fidelity="minute_adverse_first")


def replay(rules: FirmRules, slots: Sequence[Slot], shapes: Sequence[TradeShape],
           order: Sequence[int]):
    """Run the funded ledger over the slots with ``shapes[order[i]]`` in slot ``i``.

    A slot whose account refuses entries (payout protection or processing) is
    counted as refused and its trade is skipped, as the simulator does with a
    refused strategy signal. Returns the finished ledger.
    """

    ledger = _ledger(rules)
    ledger.start()
    for number, (slot, pick) in enumerate(zip(slots, order, strict=False)):
        if slot.entry_ns >= rules.cutoff_ns:
            break
        ledger.run_until(slot.entry_ns - MINUTE_NS)
        reason = ledger.gate()
        if reason is not None:
            ledger.note_blocked(slot.entry_ns, reason,
                                "the resampled trade in this slot was refused")
            continue
        shape = shapes[int(pick)]
        ledger.open(ts_ns=slot.entry_ns, trade_ref=f"slot-{number + 1}",
                    direction=shape.direction, entry_ticks=shape.entry_ticks,
                    stop_ticks=shape.stop_ticks, target_ticks=shape.target_ticks,
                    trading_day=slot.trading_day,
                    strategy={"trade_id": f"resampled-{shape.index}"})
        if ledger.position is None:  # the entry cost alone reached the loss limit
            continue
        ledger.run_until(slot.entry_ns)
        ledger.on_minute(_observations(slot, shape), deadline_minute=True,
                         trading_day=slot.trading_day)
        if ledger.position is not None:  # pragma: no cover - the deadline always closes
            raise AssertionError("the synthetic trade did not close")
    ledger.finish()
    return ledger


@dataclass(frozen=True)
class LedgerOutcome:
    """What one replay produced (exact cents, one firm)."""

    net_cash_cents: int
    received_cents: int
    costs_cents: int
    payouts: int
    accounts: int
    #: per account bought: (payouts received, failed, trades taken)
    account_rows: tuple[tuple[int, bool, int], ...]
    #: the first account: "paid", "died" or "going", and trades taken until then
    first_fate: str
    first_trades: int | None
    trade_nets: tuple[int, ...] = ()
    trade_failed: tuple[bool, ...] = ()


def ledger_outcome(ledger) -> LedgerOutcome:
    first = ledger.accounts[0]
    receipts = [e for e in ledger.payout_events if e.get("event") == "received"]
    first_receipts = [e["ts_ns"] for e in receipts if e["account_id"] == first.account_id]
    first_trades = [t for t in ledger.trades if t["account_id"] == first.account_id]
    if first_receipts:
        paid_at = min(first_receipts)
        fate = "paid"
        trades_until = sum(1 for t in first_trades if t["exit_ns"] <= paid_at)
    elif first.failed_ns is not None:
        fate, trades_until = "died", len(first_trades)
    else:
        fate, trades_until = "going", None
    return LedgerOutcome(
        net_cash_cents=int(ledger.receipts - ledger.costs),
        received_cents=int(ledger.receipts), costs_cents=int(ledger.costs),
        payouts=len(receipts), accounts=len(ledger.accounts),
        account_rows=tuple((a.payouts_received, a.failed_ns is not None, a.trades)
                           for a in ledger.accounts),
        first_fate=fate, first_trades=trades_until,
        trade_nets=tuple(int(t["net_pnl_cents"]) for t in ledger.trades),
        trade_failed=tuple(bool(t["account_failed"]) for t in ledger.trades))


# ── validation: the original order must reproduce the saved result ────────


@dataclass(frozen=True)
class Validation:
    firm_key: str
    firm_name: str
    trades: int
    saved: dict[str, int]
    replayed: dict[str, int]
    trades_matching: int  # trades whose net result and account loss match the record
    refused_slots: int
    inexact_shapes: int
    unpinned_shapes: int

    @property
    def exact(self) -> bool:
        return self.saved == self.replayed and self.trades_matching == self.trades

    @property
    def differences(self) -> dict[str, int]:
        return {k: self.replayed[k] - self.saved[k] for k in self.saved
                if self.replayed.get(k) != self.saved[k]}


_SAVED_KEYS = {"net_cash_cents": "net_cash_earned_cents",
               "received_cents": "payouts_received_cents",
               "payouts": "payouts_received_count", "accounts": "accounts_purchased",
               "costs_cents": "account_costs_cents"}


def build_inputs(study: FundedStudy, configuration: str, firm_key: str, *, source: Any,
                 minutes: MinuteIndex | None = None
                 ) -> tuple[FirmRules, tuple[Slot, ...], tuple[TradeShape, ...]]:
    rules = firm_rules(study, configuration, firm_key, source=source)
    rows = ordered_trades(study, configuration, firm_key)
    shapes = tuple(trade_shape(r, i, tick_value_cents=rules.tick_value_cents,
                               mills=rules.cost_per_contract_mills, minutes=minutes)
                   for i, r in enumerate(rows))
    return rules, slots_from_rows(rows), shapes


def validate_original_order(study: FundedStudy, configuration: str, firm_key: str, *,
                            source: Any, minutes: MinuteIndex | None = None) -> Validation:
    """Replay the saved order through the adapter and compare with the saved summary."""

    rules, slots, shapes = build_inputs(study, configuration, firm_key, source=source,
                                        minutes=minutes)
    return check_original(study, configuration, firm_key, rules, slots, shapes)


def check_original(study: FundedStudy, configuration: str, firm_key: str, rules: FirmRules,
                   slots: Sequence[Slot], shapes: Sequence[TradeShape]) -> Validation:
    """The saved order through the adapter, compared with the saved summary and trades."""

    ledger = replay(rules, slots, shapes, range(len(shapes)))
    outcome = ledger_outcome(ledger)
    summary = study.summary(configuration, firm_key) or {}
    saved = {mine: int(summary.get(theirs) or 0) for mine, theirs in _SAVED_KEYS.items()}
    replayed = {k: int(getattr(outcome, k)) for k in _SAVED_KEYS}
    rows = ordered_trades(study, configuration, firm_key)
    matching = sum(
        1 for row, net, failed in zip(rows, outcome.trade_nets, outcome.trade_failed,
                                      strict=False)
        if _cents(row["net_pnl_usd"]) == net and bool(row["account_failed"]) == failed)
    refused = sum(sum(a.blocked_entries.values()) for a in ledger.accounts)
    return Validation(
        firm_key=firm_key, firm_name=rules.firm_name, trades=len(shapes), saved=saved,
        replayed=replayed,
        trades_matching=matching if len(outcome.trade_nets) == len(rows) else 0,
        refused_slots=refused, inexact_shapes=sum(1 for s in shapes if not s.exact),
        unpinned_shapes=sum(1 for s in shapes if not s.order_pinned))


# ── the full race over resampled orders ───────────────────────────────────


def extension_seed(seed: int) -> int:
    """The seed that continues each path past ``RACE_DRAW_LENGTH`` trades (derived, fixed)."""

    return int(np.random.SeedSequence((int(seed), RACE_DRAW_LENGTH)).generate_state(1)[0])


def shared_trades(count: int) -> int:
    """How many trades of each full-version path are exactly the chart's draw."""

    return min(int(count), RACE_DRAW_LENGTH)


def race_orders(count: int, *, paths: int, seed: int, method: str = "blocks") -> np.ndarray:
    """Resampled orders as trade indices: the fixed-floor race's own draws.

    The fixed-floor race draws ``RACE_DRAW_LENGTH`` trades per path. The indices
    are drawn exactly the same way (same seed, method and length), so the first
    ``min(count, RACE_DRAW_LENGTH)`` trades of path *i* here are path *i* of the
    chart, for every path. A study with more trade slots than that continues
    each path with a second draw of the remaining slots from
    :func:`extension_seed` (those trades are not in the chart, which stops at
    ``RACE_DRAW_LENGTH``).
    """

    index = np.arange(count, dtype=float)
    draws = resample_paths(index, paths=paths, length=RACE_DRAW_LENGTH, method=method,
                           seed=seed)
    if count > RACE_DRAW_LENGTH:
        more = resample_paths(index, paths=paths, length=count - RACE_DRAW_LENGTH,
                              method=method, seed=extension_seed(seed))
        draws = np.concatenate([draws, more], axis=1)
    return draws[:, :count].astype(int)


@dataclass(frozen=True)
class FullRace:
    firm_key: str
    firm_name: str
    paths: int
    seed: int
    method: str
    slots: int
    paid_share: float
    died_share: float
    still_going_share: float
    typical_to_payout: float | None
    typical_to_limit: float | None
    #: average payouts received by an account that was lost, before it was lost
    payouts_before_death: float | None
    lost_accounts: int
    #: all paths' cash received after the split minus their account costs ÷ accounts bought
    cash_per_account: float | None
    accounts_bought: int
    net_cash_bad: float
    net_cash_typical: float
    net_cash_good: float
    seconds: float = 0.0
    validation: Validation | None = field(default=None, compare=False)
    #: every run's net cash in dollars, in run order (for the actual result's standing)
    net_cash_values: tuple[float, ...] = field(default=(), compare=False, repr=False)

    def share_below(self, actual: float) -> float | None:
        """Share of runs whose net cash was below ``actual``; ties count half."""

        if not self.net_cash_values:
            return None
        values = np.asarray(self.net_cash_values, dtype=float)
        below = float((values < actual - 0.005).sum())
        ties = float((np.abs(values - actual) <= 0.005).sum())
        return (below + 0.5 * ties) / values.size


def full_race(rules: FirmRules, slots: Sequence[Slot], shapes: Sequence[TradeShape], *,
              paths: int, seed: int, method: str = "blocks",
              progress: Callable[[int, int], None] | None = None,
              validation: Validation | None = None) -> FullRace:
    """Every path: the study's calendar and slots with one resampled order of the trades.

    The first account of each path is the race (paid first: its first payout was
    received; died first: it was lost before any payout; still going: neither by
    the cutoff). The whole path, with replacements, gives the payouts an account
    received before it was lost and the cash per account bought.
    """

    import time

    started = time.monotonic()
    orders = race_orders(len(shapes), paths=paths, seed=seed, method=method)
    fates: list[str] = []
    to_payout: list[int] = []
    to_limit: list[int] = []
    lost_payouts: list[int] = []
    nets: list[int] = []
    total_net = 0
    total_accounts = 0
    for number, order in enumerate(orders):
        outcome = ledger_outcome(replay(rules, slots, shapes, order))
        fates.append(outcome.first_fate)
        if outcome.first_fate == "paid" and outcome.first_trades is not None:
            to_payout.append(outcome.first_trades)
        elif outcome.first_fate == "died" and outcome.first_trades is not None:
            to_limit.append(outcome.first_trades)
        lost_payouts.extend(p for p, failed, _t in outcome.account_rows if failed)
        nets.append(outcome.net_cash_cents)
        total_net += outcome.net_cash_cents
        total_accounts += outcome.accounts
        if progress is not None:
            progress(number + 1, paths)
    count = max(1, len(fates))
    paid = sum(1 for f in fates if f == "paid") / count
    died = sum(1 for f in fates if f == "died") / count
    net_usd = np.asarray(nets, dtype=float) / 100
    return FullRace(
        firm_key=rules.firm_key, firm_name=rules.firm_name, paths=paths, seed=seed,
        method=method, slots=len(slots), paid_share=paid, died_share=died,
        still_going_share=max(0.0, 1.0 - paid - died),
        typical_to_payout=float(np.median(to_payout)) if to_payout else None,
        typical_to_limit=float(np.median(to_limit)) if to_limit else None,
        payouts_before_death=(float(np.mean(lost_payouts)) if lost_payouts else None),
        lost_accounts=len(lost_payouts),
        cash_per_account=(total_net / 100 / total_accounts) if total_accounts else None,
        accounts_bought=total_accounts,
        net_cash_bad=float(np.percentile(net_usd, 5)),
        net_cash_typical=float(np.median(net_usd)),
        net_cash_good=float(np.percentile(net_usd, 95)),
        seconds=round(time.monotonic() - started, 1), validation=validation,
        net_cash_values=tuple(float(v) for v in net_usd))


def open_source(plan: Any):
    """The study's verified strategy package as a comparison source (read only)."""

    from alpha_lab.agents.data_infra.ifvg.presentation.lab.market import study_package_root
    from alpha_lab.propsim.funded.comparison_source import open_comparison_source

    root = study_package_root(plan)
    if root is None:
        return None
    return open_comparison_source(Path(root))
