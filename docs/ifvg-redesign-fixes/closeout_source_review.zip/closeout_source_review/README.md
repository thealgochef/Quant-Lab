# Source-review attachment (analytical corrections A1–A11)

Before/after copies of the changed analytical and review helpers, the screens that call them,
and the new tests, taken from git trees (not from a working copy):

- `before/` = pre-task tree `811f4b3889a53467a58b5c100f8a0075d65ec4b9` (HEAD 1b9d407 plus the uncommitted redesign, fixes and
  theme work that existed before this task);
- `after/` = final tree `76bb3b0c514b0d1fba2fcfec17beb1694943b6c7` (the tree that ran the final test suite);
- `changes.diff` = the task-only diff of these files; `SOURCE_IDENTITY.json` = blob ids.

What runs on its own: with numpy, pandas and scipy installed and `after/src` on PYTHONPATH,
the pure helpers `presentation/lab/market.py` (entry-known labels), `minute_companion.py`,
`resampling.py`, `review_panels.py` and the leg split in `funded_measures.py` import only
files included here (the package `__init__` files, `chicago_time.py`, `format.py`, `html.py`,
`funded_data.py`, `theme.py`) plus numpy, pandas and scipy; the closeout's assembler ran a smoke
check from the extracted attachment alone (`validation_summary.json`, `source_review_attachment`). What does not:
`firm_race.py` drives the repository's funded ledger (`alpha_lab.propsim.funded`, unchanged,
not included), the screens need Streamlit and the rest of the application, and the tests need
the repository's fixtures and, for reference tests, the saved study. Those parts are therefore
reported (source visible here, executed in the repository's final test run), not
independently executable from this attachment alone. No repository, environment, cache, store
or market data is included.
